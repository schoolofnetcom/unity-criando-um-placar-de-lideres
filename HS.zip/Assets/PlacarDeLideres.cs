﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;

public class PlacarDeLideres : MonoBehaviour {


    List<Pontuacao> listPontuacoes = new List<Pontuacao>();
    string diretorio;

	void Start () {
        // Definir o diretorio
        diretorio = Application.dataPath + "/placar.bin";
        // Carregar
        Text conteudoDoPlacar = GameObject.FindGameObjectWithTag("PlacarConteudo").GetComponent<Text>();

        VerificarSeArquivoExiste();
        listPontuacoes = LerArquivo();

        listPontuacoes = ordenarLista(listPontuacoes);

        foreach(Pontuacao p in listPontuacoes)
        {   
            // Adicionando conteudo jo final do texto
            conteudoDoPlacar.text = conteudoDoPlacar.text + p.jogador + "\t\t\t " + p.valor + "\n";
        }
    }

    List<Pontuacao> LerArquivo()
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream stream = new FileStream(diretorio, FileMode.Open);
        List<Pontuacao> p = bf.Deserialize(stream) as List<Pontuacao>;
        stream.Close();
        return p;
    }

    void VerificarSeArquivoExiste()
    {
        if (File.Exists(diretorio))
        {
            return;
        }
        else
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream stream = new FileStream(diretorio, FileMode.Create);
            bf.Serialize(stream, listPontuacoes);
            stream.Close();
        }
    }

    List<Pontuacao> ordenarLista(List<Pontuacao> p)
    {
        return p.OrderBy(o => -o.valor).ToList();
    }

}
