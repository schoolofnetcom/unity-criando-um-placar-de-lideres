﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CarregaNomeDoJogador : MonoBehaviour {

	
	void Start () {
        // Carrega o texto
        Text texto = GetComponent<Text>();
        // O conteúdo do texto é igual ao conteúdo da PlayerPref
        texto.text = PlayerPrefs.GetString("nome_do_jogador");
	}
	
}
