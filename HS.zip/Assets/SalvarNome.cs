﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SalvarNome : MonoBehaviour {

    Text nomeConteudo;

	// Use this for initialization
	void Start () {
        nomeConteudo = GameObject.FindGameObjectWithTag("CampoNome").GetComponent<Text>();
	}
	
    //É chamada sempre quando eu clico no botão
    public void SalvarNomeEIniciarJogo()
    {
        // Eu salvo o conteúdo do campo de texto em uma PlayerPref
        PlayerPrefs.SetString("nome_do_jogador", nomeConteudo.text);

        // Carrego uma nova fase
        SceneManager.LoadScene("Jogo");
    }

}
