﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;

public class GerenciadorDePontos : MonoBehaviour {


    string diretorio;

    public int pontuacao = 0;

    List<Pontuacao> listPontuacoes = new List<Pontuacao>();

    Text pontuacaoAtualTXT;
    Text maiorPontuacaoTXT;

	void Start () {

        // Definir o diretorio
        diretorio = Application.dataPath + "/placar.bin"; 
        // Carregando o objeto do texto
        pontuacaoAtualTXT = GameObject.FindGameObjectWithTag("PontuacaoAtual").GetComponent<Text>();
        // Carregando o objeto de texto da maior pontuacao
        maiorPontuacaoTXT = GameObject.FindGameObjectWithTag("MaiorPontuacao").GetComponent<Text>();
        // Quando o jogo começar
        VerificaSeEAMaior(pontuacao);

        VerificarSeArquivoExiste();
        listPontuacoes = LerArquivo();

        listPontuacoes = ordenarLista(listPontuacoes);

        foreach (Pontuacao pontuacao in listPontuacoes)
        {
            Debug.Log("Jogador: " + pontuacao.jogador + " Pontos: " + pontuacao.valor);
        }
    }
	
    List<Pontuacao> LerArquivo()
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream stream = new FileStream(diretorio, FileMode.Open);
        List<Pontuacao> p = bf.Deserialize(stream) as List<Pontuacao>;
        stream.Close();
        return p;
    }

    void EscreverArquivo(List<Pontuacao> p)
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream stream = new FileStream(diretorio, FileMode.Open);
        bf.Serialize(stream,p);
        stream.Close();
    }

    void VerificarSeArquivoExiste()
    {
        if (File.Exists(diretorio))
        {
            return;
        }
        else
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream stream = new FileStream(diretorio, FileMode.Create);
            bf.Serialize(stream, listPontuacoes);
            stream.Close();
        }
    }

    public void SalvarPontuacao()
    {
        // Defino um novo dado de pontuacao
            Pontuacao p = new Pontuacao();
            p.jogador = PlayerPrefs.GetString("nome_do_jogador");
            p.valor = pontuacao;
        // Adiciono esse dado na lista
            listPontuacoes.Add(p);
        // Escrevo toda a lista no arquivo
        EscreverArquivo(listPontuacoes);
    }

    List<Pontuacao> ordenarLista(List<Pontuacao> p)
    {
        return p.OrderBy(o => -o.valor).ToList();
    }

    // É chamada sempre que eu clico no botão
    public void Pontuar()
    {   
        // Pontuo +1
        pontuacao += 1;
        // Atualizo o conteúdo do texto central
       pontuacaoAtualTXT.text = pontuacao.ToString();
       // Verifica se é maior
       VerificaSeEAMaior(pontuacao);
    }

    void VerificaSeEAMaior(int pontuacaoAtual)
    {

        // Se já existir uma maior pontuação
        if (PlayerPrefs.HasKey("maior_pontuacao"))
        {
            // Se a pontuacao atual, for maior do que a maior pontuacao salva
            if (pontuacaoAtual > PlayerPrefs.GetInt("maior_pontuacao"))
            {
                // Se eh maior, ela eh a maior pontuacao de todas
                PlayerPrefs.SetInt("maior_pontuacao", pontuacaoAtual);
            }
        }
        // Se ainda não existir uma maior pontuação
        else
        {
            PlayerPrefs.SetInt("maior_pontuacao", pontuacaoAtual);
        }


        // Atualizar o texto
        AtualizaMaiorPontuacaoTXT(PlayerPrefs.GetInt("maior_pontuacao"));
    }


    void AtualizaMaiorPontuacaoTXT(int maiorPontuacao)
    {
        maiorPontuacaoTXT.text = maiorPontuacao.ToString(); 
    }
}
